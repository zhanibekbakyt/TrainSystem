public class Disabled extends Passenger {

    Disabled(String trainNumber, String seatNumber, String firstName, String secondName, String disability, int age, String price) {
        super(trainNumber, seatNumber, firstName, secondName, disability, age, price);
    }

}
